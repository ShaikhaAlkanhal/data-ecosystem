<?php
include 'connection.php';
session_start();
?>
<!doctype html>
<html>
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HomePage</title>
    <link rel="stylesheet" href="style.css">

    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <script src="javaScript.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
         <link rel="stylesheet" type="text/css" href="clock_style.css">
         
        <script type="text/javascript">
            function drawChart() {
                // call ajax function to get sports data
                var jsonData = $.ajax({
                    url: "getData.php",
                    dataType: "json",
                    async: false
                }).responseText;
                //The DataTable object is used to hold the data passed into a visualization.
                var data = new google.visualization.DataTable(jsonData);

                // To render the pie chart.
                var chart = new google.visualization.PieChart(document.getElementById('piechart'));
                chart.draw(data, {width: 200, height:92});
            }
            // load the visualization api
            google.charts.load('current', {'packages':['corechart']});

            // Set a callback to run when the Google Visualization API is loaded.
            google.charts.setOnLoadCallback(drawChart);
        </script>

     <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <style>
        
    TableContainer {
  border-collapse: collapse;
  box-shadow: 0 5px 10px #e1e5ee;
  background-color: white;
  text-align: left;
  overflow: hidden;}

  thead {
    box-shadow: 0 5px 10px #e1e5ee;
  }

  th {
    padding: 1rem 2rem;
    text-transform: uppercase;
    letter-spacing: 0.1rem;
    font-size: 0.7rem;
    font-weight: 900;
  }

  td {
    padding: 1rem 2rem;
  }

  a {
    text-decoration: none;
    color: #2962ff;
  }

 
    
     .status-Confirm{
      background-color: #c8e6c9;
      color: #388e3c;
       padding: 0.2rem 1rem;
    text-align: center;
    border-radius: 0.2rem;
    }
   


    </style>
   </head>
<body>
  <div class="sidebar">
    <div class="logo">

      <span class="logo_name">Admin Home Page</span>
    </div>
      <ul class="nav-links">
        <li>
            <a href="AdminHomePage.php" class="active">
            <i class='bx bx-grid-alt' ></i>
            <span class="links_name">Dashboard</span>
          </a>
        </li>

        <li>
            <a href="CreateTask.php">
            <i class='bx bx-box' ></i>
            <span class="links_name">Create Task</span>
          </a>
        </li>
       
 <li>
            <a href="projects.php">
            <i class='bx bx-message' ></i>
            <span class="links_name">Projects </span>
          </a>
        </li>


        <li>
            <a href="CreateUser.php">
            <i class='bx bx-user' ></i>
            <span class="links_name">Create User</span>
          </a>
        </li>
        
         <li>
            <a href="DeleteUser.php">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Delete User</span>
          </a>
        </li>
        <li>
            <a href="Download.php">
            <i class='bx bx-coin-stack' ></i>
            <span class="links_name">Downloads</span>
          </a>
        </li>
        
        <li class="log_out">
            <a href="logOut.php" onclick="window.location.href='index.php'">
            <i class='bx bx-log-out'></i>
            <span class="links_name">Log out</span>
          </a>
        </li>
      </ul>
  </div>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">Dashboard</span>
      </div>
      <div class="search-box">
        <input type="text" placeholder="Search...">
        <i class='bx bx-search' ></i>
      </div>
      <div class="profile-details">
        <!--<img src="images/profile.jpg" alt="">--> 
         
          <span class="admin_name">Admin name</span>
        <i class='bx bx-chevron-down' ></i>
      </div>
    </nav>

    <div class="home-content">
      <div class="overview-boxes">
        <div class="box">
          <div class="right-side">
            <div class="box-topic"> Summary </div>
            <div id="piechart"></div>
           
            <div class="number"> </div>
            <div class="indicator">

              <span class="text"> </span>
            </div>
          </div>

        </div>
        <div class="box"  style="width: 200; height:200;">
          <div class="right-side">
              <div class="box-topic"> Date & time</div>
              <br><br>
             <p id="date"></p>
                 <p id="time"></p>
                 <br>
            <div class="number"></div>
            <div class="indicator">

              <span class="text"></span>
            </div>
          </div>

        </div>
        <div class="box" style="width: 200; height:200;">
          <div class="right-side">
            <div class="box-topic">Number of projects</div>
            <br><br>
            <?php
          $sql = "SELECT id FROM forminfo2";
 
           $mysqliStatus = $conn->query($sql);
 
             $rows_count_value = mysqli_num_rows($mysqliStatus);
             
            
            ?>
            <p style="text-align:center;"><?php  echo $rows_count_value; ?></p>
            <br><br>
            <div class="number"></div>
            <div class="indicator">

              <span class="text"></span>
            </div>
          </div>

        </div>
        <div class="box" style="width: 200; height:200;">
          <div class="right-side">
            <div class="box-topic"> Data collectors</div><br><br>
            <?php
          $sql = "SELECT id FROM user";
 
           $mysqliStatus = $conn->query($sql);
 
             $rows_count_value = mysqli_num_rows($mysqliStatus);
             
            
            ?>
            <p style="text-align:center;"><?php  echo $rows_count_value; ?></p>
            <br><br>
            <div class="number"></div>
            <div class="indicator">

              <span class="text"></span>
            </div>
          </div>

        </div>
      </div>

      <div class="sales-boxes">
        <div class="recent-sales box">
          <div class="title">Map</div>
           <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d15300.941147813362!2d46.64279029491766!3d24.740628064454377!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sar!2ssa!4v1625998782272!5m2!1sar!2ssa" width="500" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
           
          <div class="sales-details">
            <ul class="details">
              <li class="topic"></li>

            </ul>
            <ul class="details">
            <li class="topic"></li>

          </ul>
          <ul class="details">
            <li class="topic"></li>

          </ul>
          <ul class="details">
            <li class="topic"></li>

          </ul>
          </div>

        </div>
        <div class="top-sales box">
          <div class="title">Approved projects</div>
          <br>
          <div class="card-body">
      
                
               <table id="table" class="TableContainer">
			<thead>
			<tr>
			
			<th>Project Name</th>					
			<th>Status</th>	
                        	
			</tr>
			</thead>
			<tbody>
	<?php
               						
	$query2=$conn->query("SELECT task_name , status FROM forminfo2 WHERE admin_id = '".$_SESSION['id']."' AND status = 1" ) ;
        
	while($row3=$query2->fetch_array()){
            $formid =$row3['status'];
	?>
	<tr>
            <td> <?php echo $row3['task_name'];?></td>
        <td class="status-Confirm">Confirmed</td>
     
	
	
	</tr>
	<?php
	}
	?>
	</tbody>
	</table>
           
	</div>
          
          
          
          <ul class="top-sales-details">


          <li>
            <a href="#">

              <span class="product"></span>
            </a>
            <span class="price"></span>
          </li>

          </ul>
        </div>
      </div>
    </div>
  </section>

  <script>
   let sidebar = document.querySelector(".sidebar");
let sidebarBtn = document.querySelector(".sidebarBtn");
sidebarBtn.onclick = function() {
  sidebar.classList.toggle("active");
  if(sidebar.classList.contains("active")){
  sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right"); }else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu"); }  </script>
  <script type="text/javascript">
    window.onload = setInterval(clock,1000);

    function clock()
    {
	  var d = new Date();
	  
	  var date = d.getDate();
	  
	  var month = d.getMonth();
	  var montharr =["Jan","Feb","Mar","April","May","June","July","Aug","Sep","Oct","Nov","Dec"];
	  month=montharr[month];
	  
	  var year = d.getFullYear();
	  
	  var day = d.getDay();
	  var dayarr =["Sun","Mon","Tues","Wed","Thurs","Fri","Sat"];
	  day=dayarr[day];
	  
	  var hour =d.getHours();
      var min = d.getMinutes();
	  var sec = d.getSeconds();
	
	  document.getElementById("date").innerHTML=day+" "+date+" "+month+" "+year;
	  document.getElementById("time").innerHTML=hour+":"+min+":"+sec;
    }
  </script>


</body>

    
    

    
    
</html>