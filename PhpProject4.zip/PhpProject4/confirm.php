<?php
include('connection.php');

$confirm = $conn->query("UPDATE forminfo2 SET status = 1 WHERE id = '".$_POST['id']."'");


?>