<?php
 session_start();
// Create database connection
include 'connection.php';

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Forms</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="stylesheet" href="style.css">

        <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script src="//geodata.solutions/includes/countrystatecity.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
              crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

        <style type="text/css">


            form div {
                margin-top: 5px;
            }

            #img_div {
                width: 80%;
                padding: 5px;
                margin: 15px auto;
                border: 1px solid #cbcbcb;
            }

            #img_div:after {
                content: "";
                display: block;
                clear: both;
            }

            img {
                float: left;
                margin: 5px;
                width: 300px;
                height: 140px;
            }
        </style>





    </head>
    <body>
        <div id="content">
            <?php
            // while ($row = mysqli_fetch_array($result)) {
            // echo "<div id='img_div'>";
            //echo "<img src='images/".$row['image']."' >";
            // echo "<p>".$row['image_text']."</p>";
            // echo "</div>";
            // }
            ?>


            <div class="sidebar">
                <div class="logo">

                    <span class="logo_name">User Home Page</span>
                </div>
                <ul class="nav-links">
                   

                   
                    
                    <li>
                        <a href="userProjects.php">
                            <i class='bx bx-message'></i>
                            <span class="links_name">Projects </span>
                        </a>
                    </li>
                    

                    <li>
                        <a href="feedback.php">
                            <i class='bx bx-coin-stack'></i>
                            <span class="links_name">Feedback</span>
                        </a>
                    </li>
                    </li>
                    <li class="log_out">
                        <a href="logOut.php" onclick="window.location.href = 'index.php'">
                            <i class='bx bx-log-out'></i>
                            <span class="links_name">Log out</span>
                        </a>
                    </li>
                </ul>
            </div>


            <section class="home-section">

                <nav>
                    <div class="sidebar-button">
                        <i class='bx bx-menu sidebarBtn'></i>
                        <span class="dashboard">Forms</span>
                    </div>
                    <div class="search-box">
                        <input type="text" placeholder="Search...">
                        <i class='bx bx-search'></i>
                    </div>
                    <div class="profile-details">
                        <!--<img src="images/profile.jpg" alt="">-->
                        <span class="admin_name">User name</span>
                        <i class='bx bx-chevron-down'></i>
                    </div>
                </nav>

                <br><br><br><br>
                <div class="home-content1">
                    <div class="overview-boxes1">
                        <div class="box1">
                            <div class="right-side">

                                <div class="mt-5 alert alert-danger alert-dismissible fade error_display">
                                    <a href="#" class="close" aria-label="close">&times;</a>

                                </div>
                                <div class="container" style="width:600px;">


                                    <form id="main_form" method="POST" action=""> 
                                        <input type="hidden" name="size" value="1000000">
                                        <div class="form-group">
                                            <br><br>
                                            
                                            <label>Enter your Name:</label>
                                            <input type="text" name="name" id="name" class="form-control"/>
                                            <br>
                                            
                                            <br>
                                            <?php 
                                            $guidename=$conn->query("SELECT guide_lines FROM forminfo2 WHERE id = '".$_GET['id']."'") ; 
                                            $all_media=$conn->query("SELECT * FROM form_media WHERE form_id = '".$_GET['id']."'");
                                            while($row4=$guidename->fetch_array()){
                                           
                                            ?>
                                            
                                            <label>Guidelines:</label> <br>
                                            
                                            <label class="form-control"> <a href=localhost:8888\PhpProject4\Uploads\<?php echo$row4['guide_lines'];?> ><?php echo $row4['guide_lines'];?></a> </label> <br>
                                             <?php 
                                            }
                                             ?>
                                           <label>Country:</label><br>
                                             <div class="search">
                                                 <div class="select">
                                                     <select name="country" class="countries" id="countryId"
                                                             class="form-control" required>
                                                         <option value="">Select Country</option>
                                                     </select></div>
                                             </div>
                                             <br>
                                             <label>State:</label><br>
                                             <div class="search">
                                                 <div class="select">
                                                     <select name="state" class="states" id="stateId" class="form-control" required>
                                                         <option value="">Select State</option>
                                                     </select></div>
                                             </div>
                                             <br>
                                             <label>City:</label><br>
                                             <div class="search">
                                                 <div class="select">
                                                     <select name="city" class="cities" id="cityId" class="form-control" required>
                                                         <option value="">Select City</option>
                                                     </select></div>
                                             </div>
                                             <br>
                                             
                                             <?php
                                              while ($row5=$all_media->fetch_array()){
                                               $media_required= $row5['media_required']==1?"required":"";
                                               $description_req=$row5['media_description_req']==1?"required":"";
                                                  
                                             
                                             ?>
                                             
                                              <label>Please Add <?php echo $row5['media_name'];   ?> :</label><br>
                                             <div class="">
                                                 <input type="file" name=" <?php echo $row5['media_name']; ?>[]" class="form-control" <?php echo $media_required; ?>>                                        
                                                 
                                             </div>
                                             <div class="">
                                                 <textarea name="<?php echo $row5['media_name']; ?>_desc[]" class="form-control" <?php echo $description_req?>></textarea>
                                                 
                                                 
                                             </div>
                                             <br>
                                             
                                             <?php } ?>
                                             
                                         </div> 


                                            <div class="form-group">

                                                <br>
                                                <button type="submit" name="submit" class="btn btn-info" value="Save"
                                                        onclick="submit_form()"> Save
                                                </button>
                                            </div> 
                                                 </form>
                                    <script src="https://code.jquery.com/jquery-3.6.0.min.js" crossorigin="anonymous"></script>

                                    <script src="https://code.jquery.com/jquery-3.6.0.min.js" crossorigin="anonymous"></script>
                                    
                                   
                                     <?php
                                    if($_SERVER["REQUEST_METHOD"]=="POST"){
                                        
                                        $country= isset($_POST['country'])?$_POST['country']:"";
                                        $state= isset($_POST['state'])?$_POST['state']:"";
                                        $city= isset($_POST['city'])?$_POST['city']:"";
                                        $sql= "UPDATE forminfo2 SET country = '$country', state = '$state', city = '$city'  WHERE id = '".$_GET['id']."'";
                                        
                                        $run = mysqli_query($conn, $sql);
                                          echo json_encode(["sql"=>$sql]);
                                        
                                         $image = isset( $_POST['image'])?$_POST['image']:"";
                                        $video = isset($_POST['video'])?$_POST['video']:"";
                                         $audio = isset($_POST['audio'])?$_POST['audio']:"";
                                          $text = isset($_POST['text'])?$_POST['text']:"";
                                           $xls = isset($_POST['xls'])?$_POST['xls']:"";
                                        $image_desc = isset($_POST['image_desc'])?$_POST['image_desc']:"";
                                        $video_desc = isset($_POST['video_desc'])?$_POST['video_desc']:"";
                                         $audio_desc = isset($_POST['audio_desc'])?$_POST['audio_desc']:"";
                                         $text_desc = isset($_POST['text_desc'])?$_POST['text_desc']:"";
                                         $xls_desc = isset($_POST['xls_desc'])?$_POST['xls_desc']:"";
                                         
                                         $insert_array = array();
                                         
                                         $date = date('Y-m-d H:i:s');
                                        
                                         foreach ($image as $key=>$val){
                                          $insert_array["image"][]=$val;
                                          $insert_array["image_desc"][]=$image_desc[$key];
                                             
                                         }
                                         
                                         foreach ($video as $key2=>$val2){
                                          $insert_array["video"][]=$val2;
                                          $insert_array["video_desc"][]=$video_desc[$key2];
                                             
                                         }
                                         
                                         
                                         foreach ($audio as $key3=>$val3){
                                          $insert_array["audio"][]=$val3;
                                          $insert_array["audio_desc"][]=$audio_desc[$key3];
                                             
                                         }
                                         
                                         foreach ($text as $key4=>$val4){
                                          $insert_array["text"][]=$val4;
                                          $insert_array["text_desc"][]=$text_desc[$key4];
                                             
                                         }
                                         
                                         foreach ($xls as $key5=>$val5){
                                          $insert_array["xls"][]=$val5;
                                          $insert_array["xls_desc"][]=$xls_desc[$key5];
                                             
                                         }
                                         
                                         
                                          $INSERT_JSON = json_encode($insert_array);
                                         $sql22 = "INSERT INTO user_responses (user_id , form_id , created_on , response) VALUES (".$_SESSION['id']." , '".$_GET['id']."' , '$date' , '$INSERT_JSON')";
                                         mysqli_query($conn, $sql22);
                                       echo json_encode(["sql"=>$sql22]);
                                         
                                        
                                    }
                                    
                                    
                                    
                                    
                                    
                                    
                                    ?>
                                    
                                    
                                    
                                   

                                </div>


                            </div>
                        </div>
                    </div>
                </div>
           
            </section>

            <script>
                let sidebar = document.querySelector(".sidebar");
                let sidebarBtn = document.querySelector(".sidebarBtn");
                sidebarBtn.onclick = function () {
                    sidebar.classList.toggle("active");
                    if (sidebar.classList.contains("active")) {
                        sidebarBtn.classList.replace("bx-menu", "bx-menu-alt-right");
                    } else
                        sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
                }</script>


    </body>


    
</html>