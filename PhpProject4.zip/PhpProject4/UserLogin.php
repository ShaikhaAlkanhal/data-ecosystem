
<?php
$con=mysqli_connect("localhost:8889","root","root","project 1");
//handle the error
if(mysqli_connect_error()!=null){
    print("fail");
    die(mysqli_connect_error());
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
               if(isset($_POST["login"])){
    
                 $email = $_POST["email"];
                 $password = md5($_POST["password"]);

     $sql= "SELECT * FROM user WHERE email='$email' and password='$password'";

             $result = mysqli_query($con, $sql);
               if(mysqli_num_rows($result)==1){
     $user_check_query = "SELECT id FROM user WHERE email='$email'";
     $result1 = mysqli_query($con, $user_check_query);
     $user = mysqli_fetch_assoc($result1);
            $id=$user["id"];
            $_SESSION['email'] = "email";
            $_SESSION["id"]= $id;
          

            echo "<script>";
            echo "window.location='userProjects.php'";
            echo "</script>";

               }
        else {
         echo '<script> document.getElementById("error").innerHTML= "Invalid email or password !"; </script>';
     }
        }
}
?>
