<?php
 session_start();
 include 'connection.php';
 include 'insertUser.php';
 include 'UserLogin.php';
       ?>
 <!DOCTYPE html>

<html>
    <head>
        <title>Home Page</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="newcss.css"/>

    </head>

   
    <main>
        <div class="login-wrap">
  <div class="login-html">
    <input id="tab-1" type="radio" name="tab" class="sign-in" checked><label for="tab-1" class="tab">Sign In</label>
    <input id="tab-2" type="radio" name="tab" class="sign-up"><label for="tab-2" class="tab">Sign Up</label>
    <div class="login-form">
        <form class="sign-in-htm"  method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" >
          <br>
        <div class="group">
          <label for="user" class="label">Email</label>
          <input id="email" name="email" type="email" class="input">
        </div>
        <div class="group">
          <label for="pass" class="label">Password</label>
          <input id="password" name="password" type="password" class="input" data-type="password">
          <p style="color:red; font-size: 13px;"id="error"></p>
        </div>
          <br>
        <div class="group">
            <button type="submit" name="login" id="submit" class="button" value="Sign In" >Sign In </button>
        </div>
        <div class="hr"></div>
        <div class="foot-lnk">
          
        </div>
      </form>
        <?php


          if ($_SERVER["REQUEST_METHOD"] == "POST") {
               if(isset($_POST["submit"])){
    
                 $email = $_POST["email"];
                 $password = md5($_POST["password"]);

     $sql= "SELECT * FROM user WHERE email='$email' and password='$password'";

             $result = mysqli_query($conn, $sql);
               if(mysqli_num_rows($result)==1){
     $user_check_query = "SELECT id FROM user WHERE email='$email'";
     $result1 = mysqli_query($conn, $user_check_query);
     $user = mysqli_fetch_assoc($result1);
            $id=$user["id"];
            $_SESSION['email'] = "email";
            $_SESSION["id"]= $id;
          
          header("Location:UserHomePage.php");
            echo "<script>";
            echo "window.location='UserHomePage.php'";
            echo "</script>";

               }
       


        }
}
?>

        
         <form id="signup" action="index.php" method="post" class="sign-up-htm" >

        
      <div class="group">

          

      <label for="username" class="label"><b>User name</b></label><br>
      <input type="text" placeholder="User Name" name="username" id="username" class="input"><br>

       
      <label for="email" class="label"><b>Email</b></label><br>
      <input type="email" placeholder="e-mail" name="email" id ="mail" class="input"><br>

      <label for="password" class="label"><b>Password</b></label><br>
      <input type="password" placeholder="password" name="password" id="password" class="input"><br>

     <div class="checkboxy">
         <input name="cecky" id="checky" value="1" type="checkbox" required /><label class="terms">I accept the terms of use</label><br><br>

            </div>

     

      <button type="submit" formaction="" name="submit"  class="button" onclick="window.location.href='index.php';" > Sign Up</button><br><br>

      </div>

         </form>

        
            
            






        </main>
 <script>
        function redirect (){
        window.location.href="index.php";
          }

     </script>

  <footer>
          

                </footer>
    </body>
</html>
