<?php
include('connection.php');
$review = isset($_POST['review']) ? $_POST['review'] : "";

$reject = $conn->query("UPDATE forminfo2 SET status = 2 , review = '$review'  WHERE id = '".$_POST['id']."'");
 $dropResponse = $conn->query("Delete FROM user_responses WHERE form_id = '".$_POST['id']."' ");
$dropMedia = $conn->query("Delete FROM form_media WHERE form_id = '".$_POST['id']."' ");

?>

