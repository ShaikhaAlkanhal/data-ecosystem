<?php

include 'connection.php';

if($_SERVER["REQUEST_METHOD"] == "POST"){
   
    print_r($_FILES);
    $guide_lines="";
   
    /*Update form date set guidlines where id = $_POST['id']*/
    $guide_lines = isset($_FILES['file']) ? $_FILES['file'] : ""; echo ($_POST['id']);
    $id = $_POST['id'];
    $name= $_FILES['file']['name'];
    $tmp_name= $_FILES['file']['tmp_name'];
    $samples =  isset($_POST['samples']) ? $_POST['samples'] : 0;
   
    
    for ($x = 0; $x < $samples; $x++) {
   
    $sql1= "UPDATE forminfo2 SET guide_lines ='".$guide_lines['name']."' WHERE id = $id";

if (isset($name)) {

$path= 'Uploads/';
if (!empty($name)){
if (move_uploaded_file($tmp_name, $path.$name)) {
echo 'Uploaded!';

}
}

}
 
$id =  $id -1;
    $run = mysqli_query($conn,$sql1);
    
    
    
}
    echo json_encode(["sql"=> $sql1]);
}


?>

