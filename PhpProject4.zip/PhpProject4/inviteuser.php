<?php
 use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require_once "vendor/autoload.php";
$userexist = '';


         if($_SERVER["REQUEST_METHOD"] == "POST") {

       
               
                   if (isset($_POST['email'])){
                       if(isset($_POST['username'])){
                         

        
        $username = $_POST['username'];
        //$id =  $_POST['ID'];
    
        $email = $_POST['email'];


       $result = $conn->query("SELECT username FROM user WHERE username = '$username' or email='$email'");

$row_count = $result->num_rows;
if($row_count == 1)
{
    global $userexist;
    $userexist= '<h4 style="color:red;">'.'*User exists'.'</h4>' ; } else {

         $query = "INSERT INTO user(username,email) VALUES (
            '$username','$email')";

          $run= mysqli_query($conn, $query) ;
if($run){
   

$mail = new PHPMailer;

$mail->isSMTP();


// $mail->SMTPDebug = SMTP::DEBUG_SERVER;

//Set the hostname of the mail server
$mail->Host = 'smtp.gmail.com';

$mail->Port = 587;

//Whether to use SMTP authentication
$mail->SMTPAuth = true;

//Username to use for SMTP authentication - use full email address for gmail
$mail->Username = 'data0project@gmail.com';

//Password to use for SMTP authentication
$mail->Password = 'Aa@12345678';
$mail->From = "data0project@gmail.com";
$mail->FromName = "Full Name";

$mail->addAddress($email, $username);


$mail->isHTML(true);

$mail->Subject = "Invitation";
$mail->Body = "<i>I invite you to create an account as data collector</i>";
$mail->AltBody = "This is the plain text version of the email content";

try {
    $mail->send();
    echo "Message has been sent successfully";
} catch (Exception $e) {
    echo "Mailer Error: " . $mail->ErrorInfo;
}

    
    
    
}
        
        $user_id_query = "SELECT id FROM user WHERE email='$email'";
        $result1 = mysqli_query($conn, $user_id_query);
        $user = mysqli_fetch_assoc($result1);
            $id=$user["id"];
            session_start();
           $_SESSION['id'] = $id;
           $_SESSION['email'] = "email";

            


       
         }}}}
mysqli_close($conn);

        ?>

