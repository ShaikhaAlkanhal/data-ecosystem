<?php

//insert.php

include('connection.php');


if ($_SERVER["REQUEST_METHOD"] == "POST") {


  $desReq = isset($_POST['media_description_req'])?$_POST['media_description_req']:"";
  $media= isset($_POST['media'])?$_POST['media']:"";
  $mediareq=isset($_POST['media_required'])?$_POST['media_required']:"";
    

    $task_name = isset($_POST['task_name']) ? $_POST['task_name'] : "";
  
    $deadline = isset($_POST['deadline']) ? $_POST['deadline'] : "";
    $user = isset($_POST['user']) ? $_POST['user'] : "";
   
    $id = isset($_POST['id'])?$_POST['id']:0;
 
    $date = date('Y-m-d H:i:s');
$samples =  isset($_POST['samples']) ? $_POST['samples'] : 0;
    if ($task_name == "") {
        $output['error'] = 1;
        $output['message'] = "Add task name please";
    }
    

 else if ($user ==""){
                        $output['error']=1;
                $output['message']="Add user please";}
               
                if ($id == 0) {
        $output['error'] = 1;
        $output['message'] = "please login again";
    }

     else{   
       for ($x = 0; $x < $samples; $x++) {

    $sql = "INSERT INTO forminfo2  (task_name , user_id , admin_id  , create_on , deadline) VALUES ('$task_name', '$user' , '$id' , '$date' , '$deadline' )";

    $run = mysqli_query($conn, $sql);
    $last_id= mysqli_insert_id($conn);
    $output['error']=0;
    $output['form_id']=$last_id;
    
    foreach ($media as $k =>$m){
        $sq_media = "INSERT INTO form_media (form_id , media_name , media_required , media_description_req) VALUES ($last_id ,'$m' , '$mediareq[$k]','$desReq[$k]')";
        mysqli_query($conn, $sq_media);
        
        
    }
     } }
    echo json_encode($output);
    /* }}}}} */
}




// $media=array();
//if(($media != null)){
// foreach ($media as $key => $media1) {
//  $result[]=$media1;
//}
//}
?>



