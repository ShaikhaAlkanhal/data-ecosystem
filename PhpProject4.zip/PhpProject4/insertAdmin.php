<?php
$userexist = '';


         if($_SERVER["REQUEST_METHOD"] == "POST") {

       
               if (isset($_POST['password'])){
                   if (isset($_POST['email'])){
                       if(isset($_POST['username'])){
                         

        
        $username = $_POST['username'];
        //$id =  $_POST['ID'];
        $pass = $_POST['password'];
        $email = $_POST['email'];


       $result = $conn->query("SELECT username FROM admin WHERE username = '$username' or email='$email'");

$row_count = $result->num_rows;
if($row_count == 1)
{
    global $userexist;
    $userexist= '<h4 style="color:red;">'.'*User exists'.'</h4>' ; } else {

         $query = "INSERT INTO admin(username,password,email) VALUES (
            '$username',md5('$pass'),'$email')";

          $run= mysqli_query($conn, $query) ;

        
        $user_id_query = "SELECT id FROM admin WHERE email='$email'";
        $result1 = mysqli_query($conn, $user_id_query);
        $user = mysqli_fetch_assoc($result1);
            $id=$user["id"];
            session_start();
           $_SESSION['id'] = $id;
           $_SESSION['email'] = "email";

            header("Location:AdminHomePage.php");


       
         }}}}}
mysqli_close($conn);

        ?>

