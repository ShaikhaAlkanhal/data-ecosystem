<?php
include('connection.php');

 $email = isset($_POST['autocomplete']) ? $_POST['autocomplete'] : "";

  if ($email == "") {
        $output['error'] = 1;
        $output['message'] = "Add user email please";
    }
    else{
         
$delete = $conn->query("DELETE FROM user WHERE email = '$email'");

    }
echo json_encode($output);
?>