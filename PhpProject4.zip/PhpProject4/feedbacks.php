<?php
session_start();
 include 'connection.php';
 
       ?>



<!doctype html>
<html>
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Projects</title>
    <link rel="stylesheet" href="style.css">

    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <script src="javaScript.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap.min.js"></script>		
<link rel="stylesheet" href="css/dataTables.bootstrap.min.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>


    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <style>
        
    TableContainer {
  border-collapse: collapse;
  box-shadow: 0 5px 10px #e1e5ee;
  background-color: white;
  text-align: left;
  overflow: hidden;}

  thead {
    box-shadow: 0 5px 10px #e1e5ee;
  }

  th {
    padding: 1rem 2rem;
    text-transform: uppercase;
    letter-spacing: 0.1rem;
    font-size: 0.7rem;
    font-weight: 900;
  }

  td {
    padding: 1rem 2rem;
  }

  a {
    text-decoration: none;
    color: #2962ff;
  }

 
    
     .status-Confirm{
      background-color: #c8e6c9;
      color: #388e3c;
       padding: 0.2rem 1rem;
    text-align: center;
    border-radius: 0.2rem;
    }
   


    </style>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="sidebar">
    <div class="logo">

      <span class="logo_name">Feedbacks</span>
    </div>
      <ul class="nav-links">
        
        <li>
            <a href="userProjects.php">
            <i class='bx bx-message' ></i>
            <span class="links_name">Projects </span>
          </a>
        </li>

        <li>
            <a href="feedbacks.php">
            <i class='bx bx-box' ></i>
            <span class="links_name">Feedback</span>
          </a>
        </li>



        
        <li class="log_out">
            <a href="logOut.php" onclick="window.location.href='index.php'">
            <i class='bx bx-log-out'></i>
            <span class="links_name">Log out</span>
          </a>
        </li>
      </ul>
  </div>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">Projects</span>
      </div>
      <div class="search-box">
        <input type="text" placeholder="Search...">
        <i class='bx bx-search' ></i>
      </div>
      <div class="profile-details">
        <!--<img src="images/profile.jpg" alt="">-->
        <span class="admin_name">User name</span>
        <i class='bx bx-chevron-down' ></i>
      </div>
    </nav>

    <br><br><br><br><br>
    <div class="home-content1">
      <div class="overview-boxes1">
        <div class="box1">
          <div class="right-side">
              
             <div class="card-body">
      
                
               <table id="table" class="TableContainer">
			<thead>
			<tr>
			<th>ID</th>
			<th>Project Name</th>					
			<th>Feedback</th>	
                        	
			</tr>
			</thead>
			<tbody>
	<?php
               						
	$query2=$conn->query("SELECT id , task_name , review FROM forminfo2 WHERE user_id = '".$_SESSION['id']."' AND status = 2" ) ;
        
	while($row3=$query2->fetch_array()){
            $formid =$row3['id'];
	?>
	<tr>
	<td><?php echo $row3['id']?></td>
     <?php echo "<td><a href='viewforms.php?id={$formid}'>{$row3['task_name']}</a></td>";?>
        <td><?php echo $row3['review']?></td>
     
	
	
	</tr>
	<?php
	}
	?>
	</tbody>
	</table>
           
	</div>
 
          
          </div></div></div></div>
       
    </section>
       
    
    	
	<script type="text/javascript">
		$(document).ready(function(){
			$('#table').DataTable();
		});
	</script>
	

  <script>
   let sidebar = document.querySelector(".sidebar");
let sidebarBtn = document.querySelector(".sidebarBtn");
sidebarBtn.onclick = function() {
  sidebar.classList.toggle("active");
  if(sidebar.classList.contains("active")){
  sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right"); }else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu"); }  </script>

</body>

    
    
    
    
    
</html>