<?php
$userexist = '';


         if($_SERVER["REQUEST_METHOD"] == "POST") {

       
               if (isset($_POST['password'])){
                   if (isset($_POST['email'])){
                       if(isset($_POST['username'])){
                         

        
        $username = $_POST['username'];
        //$id =  $_POST['ID'];
        $pass = $_POST['password'];
        $email = $_POST['email'];


       $result = $conn->query("SELECT username FROM user WHERE username = '$username' or email='$email'");

$row_count = $result->num_rows;
if($row_count == 1)
{
  $updateuser = $conn->query("UPDATE user set password = md5('$pass') WHERE username = '$username' or email='$email'");
  } else {

         $query = "INSERT INTO user(username,password,email) VALUES (
            '$username',md5('$pass'),'$email')";

          $run= mysqli_query($conn, $query) ;

        
        $user_id_query = "SELECT id FROM user WHERE email='$email'";
        $result1 = mysqli_query($conn, $user_id_query);
        $user = mysqli_fetch_assoc($result1);
            $id=$user["id"];
            session_start();
           $_SESSION['id'] = $id;
           $_SESSION['email'] = "email";

            


       
         }}}}}
mysqli_close($conn);

        ?>

