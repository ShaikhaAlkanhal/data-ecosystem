<?php
 session_start();
 include 'connection.php';

       ?>


<!doctype html>
<html>
    <head>
        <title>Delete User</title>
   <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="style.css">

<link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
 <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
   

 
<!-- Bootstrap CSS -->
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
<link href='bootstrap/css/bootstrap.min.css' rel='stylesheet' type='text/css'>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src='bootstrap/js/bootstrap.min.js'></script> 
<script src='bootbox.min.js'></script>



    <style>
        
         .main {
      
        width: 400px;
        height: 300px;
        margin:auto;
    }
    
    .sign {
        padding-top: 40px;
        color: #000080;
        font-family: 'Ubuntu', sans-serif;
        font-weight: bold;
        font-size: 23px;
    }
    
    .un {
    width: 76%;
    color: rgb(38, 50, 56);
    font-weight: 700;
    font-size: 14px;
    letter-spacing: 1px;
    background: rgba(136, 126, 126, 0.04);
    padding: 10px 20px;
    border: none;
    border-radius: 20px;
    outline: none;
    box-sizing: border-box;
    border: 2px solid rgba(0, 0, 0, 0.02);
    margin-bottom: 50px;
    margin-left: 46px;
    text-align: center;
    margin-bottom: 27px;
    font-family: 'Ubuntu', sans-serif;
    }
    
    form.signup {
        padding-top: 40px;
    }
    
   
    
   
    .un:focus, .pass:focus {
        border: 2px solid rgba(0, 0, 0, 0.18) !important;
        
    }
    
    .submit {
      cursor: pointer;
        border-radius: 5em;
        color: #fff;
        background: linear-gradient(to right, #000080, #4682B4);
        border: 0;
        padding-left: 40px;
        padding-right: 40px;
        padding-bottom: 10px;
        padding-top: 10px;
        font-family: 'Ubuntu', sans-serif;
        margin-left: 30%;
        font-size: 13px;
        box-shadow: 0 0 20px 1px rgba(0, 0, 0, 0.04);
    }
    
    
    button{
        text-shadow: 0px 0px 3px rgba(117, 117, 117, 0.12);
        color: #000080;
        text-decoration: none
    }
    
    @media (max-width: 600px) {
        .main {
            border-radius: 0px;
        }
    </style>
        
    
    
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="sidebar">
    <div class="logo">

      <span class="logo_name">Admin Home Page</span>
    </div>
      <ul class="nav-links">
        <li>
            <a href="AdminHomePage.php" class="active">
            <i class='bx bx-grid-alt' ></i>
            <span class="links_name">Dashboard</span>
          </a>
        </li>

        <li>
            <a href="CreateTask.php">
            <i class='bx bx-box' ></i>
            <span class="links_name">Create Task</span>
          </a>
        </li>


 <li>
            <a href="projects.php">
            <i class='bx bx-message' ></i>
            <span class="links_name">Projects </span>
          </a>
        </li>
        



        <li>
            <a href="CreateUser.php">
            <i class='bx bx-user' ></i>
            <span class="links_name">Create User</span>
          </a>
        </li>
         <li>
            <a href="DeleteUser.php">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Delete User</span>
          </a>
        </li>
        <li>
            <a href="Download.php">
            <i class='bx bx-coin-stack' ></i>
            <span class="links_name">Downloads</span>
          </a>
        </li>
        

        
        <li class="log_out">
          <a href="#" onclick="window.location.href='index.php'">
            <i class='bx bx-log-out'></i>
            <span class="links_name">Log out</span>
          </a>
        </li>
      </ul>
  </div>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">Delete User</span>
      </div>
      <div class="search-box">
        <input type="text" placeholder="Search...">
        <i class='bx bx-search' ></i>
      </div>
      <div class="profile-details">
        <!--<img src="images/profile.jpg" alt="">-->
        <span class="admin_name">Admin name</span>
        <i class='bx bx-chevron-down' ></i>
      </div>
    </nav>

 <br><br><br><br><br>
    <div class="home-content1">
      <div class="overview-boxes1">
        <div class="box1">
          <div class="right-side">
              <div class="main">
                 <p class="sign" align="center">Delete a User</p>
                 <form id="deleteform" action="index.php" method="get" class="sign-up-htm" >
 <div class="form-group">
        
     <div class="container">
  <div class="row">
      <br><br>
      <br>
      <input type="text" name="autocomplete" id="autocomplete" placeholder="search here...." class="form-control"> 
 
  </div>
         <button type="button" formaction="" name="submit" align="center"  class="submit" onclick="delete_user()" >Delete a user</button><br><br>
</div>

 </div>
         </form>
            
              </div></div></div></div></div>
        
    </section>
    

  <script>
   let sidebar = document.querySelector(".sidebar");
let sidebarBtn = document.querySelector(".sidebarBtn");
sidebarBtn.onclick = function() {
  sidebar.classList.toggle("active");
  if(sidebar.classList.contains("active")){
  sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right"); }else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu"); }  </script>
  
  
  
  
  <script src="jquery.js"></script>
  <script>
function delete_user() {

    if (confirm('Are you sure you want to delete that?')) {
        
       let user_email=$("#autocomplete").val();
            $.ajax({

                url: "delete.php",
                method: "POST",
                data:{autocomplete: user_email },
                dataType: 'json',

                success: function (e) {
                    console.log(e);
         
    }   });}}
</script>

</body>

    
    
    
    
    
</html>