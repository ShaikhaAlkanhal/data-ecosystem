<?php
$conn=mysqli_connect("localhost:8889","root","root","project 1");
//handle the error
if(mysqli_connect_error()!=null){
    print("fail");
    die(mysqli_connect_error());
}
?>
 