<?php
session_start();
include 'connection.php';
?>


<!doctype html>
<html>
    <head>
        <title>Review form</title>

        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="stylesheet" href="style.css">


        <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>


        <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script src="//geodata.solutions/includes/countrystatecity.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
              crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

        <style type="text/css">


            form div {
                margin-top: 5px;
            }

            #img_div {
                width: 80%;
                padding: 5px;
                margin: 15px auto;
                border: 1px solid #cbcbcb;
            }

            #img_div:after {
                content: "";
                display: block;
                clear: both;
            }

            img {
                float: left;
                margin: 5px;
                width: 300px;
                height: 140px;
            }
            
              .status-Confirm{
      background-color: #c8e6c9;
      color: #388e3c;
       padding: 0.1rem;
    text-align: center;
    border-radius: 0.2rem;
    }
   
    .status-pending{
        background-color: #fff0c2;
        color:  #a68b00;
         padding: 0.2rem 0.5rem;
    text-align: center;
    border-radius: 0.2rem;
    }
    .status-reject{
        background-color: #ffcdd2;
            color: #c62828;
        padding: 0.1rem;
    text-align: center;
    border-radius: 0.2rem;
    }

        </style>



    </head>
    <body>
        <div class="sidebar">
            <div class="logo">

                <span class="logo_name">Admin Home Page</span>
            </div>
            <ul class="nav-links">
                <li>
                    <a href="AdminHomePage.php" class="active">
                        <i class='bx bx-grid-alt' ></i>
                        <span class="links_name">Dashboard</span>
                    </a>
                </li>

                <li>
                    <a href="CreateTask.php">
                        <i class='bx bx-box' ></i>
                        <span class="links_name">Create Task</span>
                    </a>
                </li>
                <li>
                    <a href="projects.php">
                        <i class='bx bx-message' ></i>
                        <span class="links_name">Projects </span>
                    </a>
                </li>

                <li>
                    <a href="CreateUser.php">
                        <i class='bx bx-user' ></i>
                        <span class="links_name">Create User</span>
                    </a>
                </li>
                 <li>
            <a href="DeleteUser.php">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Delete User</span>
          </a>
        </li>
                <li>
                    <a href="Download.php">
                        <i class='bx bx-coin-stack' ></i>
                        <span class="links_name">Downloads</span>
                    </a>
                </li>

                <li class="log_out">
                    <a href="#" onclick="window.location.href = 'index.php'">
                        <i class='bx bx-log-out'></i>
                        <span class="links_name">Log out</span>
                    </a>
                </li>
            </ul>
        </div>
        <section class="home-section">
            <nav>
                <div class="sidebar-button">
                    <i class='bx bx-menu sidebarBtn'></i>
                    <span class="dashboard">Dashboard</span>
                </div>
                <div class="search-box">
                    <input type="text" placeholder="Search...">
                    <i class='bx bx-search' ></i>
                </div>
                <div class="profile-details">
                  <!--<img src="images/profile.jpg" alt="">-->
                    <span class="admin_name">Admin name</span>
                    <i class='bx bx-chevron-down' ></i>
                </div>
            </nav>

            <br><br><br><br><br> <br>

            <div class="home-content1">
                <div class="overview-boxes1">
                    <div class="box1">
                        <div class="right-side">
                            <div class="container" style="width:600px;">

                    

                                
                                
                                
                                
                                <?php
                                $inform = $conn->query("SELECT * FROM forminfo2 WHERE id = '" . $_GET['id'] . "'");
                                $all_media = $conn->query("SELECT * FROM form_media WHERE form_id = '" . $_GET['id'] . "'");
                                $sql3 = "SELECT * FROM user_responses WHERE form_id = '" . $_GET['id'] . "'";
                                $theid = $_GET['id'];
                                $result2 = mysqli_query($conn, $sql3);
                                $user2 = mysqli_fetch_assoc($result2);
                                $ff = $user2['response'];
                                $xx = (json_decode($ff));
                                
                               // if (isset($xx->xls)){
                                  //  $xls_array=$xx->xls;
                                  //  echo count($xls_array).'jjjjj';
                                  
                               // }

                                while ($row = $inform->fetch_array()) {
                                    ?>
                                   
                                        <input type="hidden" name="size" value="1000000">
                                        <div class="form-group">
                                            <br><br>
                                            <!-- <label>Enter Your Name:</label>
                                           <input type="text" name="name" id="name" class="form-control"/> -->
                                            <label>Task Name:</label>
                                                <label class="form-control"> <?php echo $row['task_name'] ?> </label>
                                                <div class="form-row" >
                                                    <div class="col">

                                                        <input type="hidden" id="admin_id" value="<?Php echo $_SESSION['id'] ?>">
                                                        <input type="hidden" id="form_id" >


                                                        <label>Deadline:</label><label  class="form-control" > <?php echo $row['deadline'] ?>  </label>
                                                        <label>Country:</label><label  class="form-control" > <?php echo $row['country'] ?>  </label>
                                                        <label>State:</label><label  class="form-control" > <?php echo $row['state'] ?>  </label>
                                                        <label>City:</label><label  class="form-control" > <?php echo $row['city'] ?>  </label>
                                                         <label>Create On:</label><label  class="form-control" > <?php echo $row['create_on'] ?>  </label>
                                                        <br>
                                                        
                                                        
                                                        
                                                        <?php
                                              $img_desc=array();
                                              $video_desc=array();
                                              $audio_desc=array();
                                              $text_desc=array();
                                              $xls_desc=array();
                                              if(isset($xx->image_desc)){
                                              $img_desc=$xx->image_desc;}
                                              
                                                if(isset($xx->video_desc)){
                                              $video_desc=$xx->video_desc;}
                                              
                                               if(isset($xx->audio_desc)){
                                              $audio_desc=$xx->audio_desc;}
                                              
                                               if(isset($xx->text_desc)){
                                              $text_desc=$xx->text_desc;}
                                              
                                               if(isset($xx->xls_desc)){
                                              $xls_desc=$xx->xls_desc;}
                                                  
                                              if(isset($xx->image)&& count($xx->image)>0){
                                                  $images_array=$xx->image;
                                                  foreach ($images_array as $key1 => $img){
                                              if($images_array[$key1] != ""){
                                             ?>
                                             <label>Image:</label> <br>
                                                        <label ><img src="Uploads/<?php echo $img;   ?>"> </label><br>
                                                        <?php if (isset($xx->image_desc))  {    ?>
                                             
                                                 <label  class="form-control" > <?php echo $img_desc[$key1];?></label>
                                                 
                                              <?php }}}} ?>
                                                 
                                                 
                                                 <?php
                                                  if(isset($xx->video)&& count($xx->video)>0){        
                                                  $videos_array=$xx->video;
                                                  foreach ($videos_array as $key2 => $vid){
                                                 if($videos_array[$key2] != ""){
                                             ?>
                                                 <label>Video:</label> <br>
                                                 <label ><video src="Uploads/<?php echo $vid;   ?>"></video> </label><br>
                                                        <?php if (isset($xx->video_desc))  {    ?>
                                             
                                                 <label  class="form-control" > <?php echo $video_desc[$key2];?></label>
                                                 
                                                  <?php }}}} ?>
                                                 
                                                 
                                                 <?php
                                                  if(isset($xx->audio)&& count($xx->audio)>0){
                                                  $audio_array=$xx->audio;
                                                  foreach ($audio_array as $key3 => $aud){
                                              if($audio_array[$key3] != ""){
                                             ?>
                                                 <label>Audio file:</label> <br>
                                                 <label ><audio src="Uploads/<?php echo $aud;   ?>"></audio> </label><br>
                                                        <?php if (isset($xx->audio_desc))  {    ?>
                                             
                                                 <label  class="form-control" > <?php echo $audio_desc[$key3];?></label>
                                                 
                                                  <?php }}} }?>
                                                 
                                            <?php
                                                  if(isset($xx->text)&& count($xx->text)>0){
                                                  $text_array=$xx->text;
                                                  foreach ($text_array as $key4 => $txt){
                                              if($text_array[$key4] != ""){
                                             ?>
                                                 
                                                  <label>text file:</label> <br>
                                            
                                            <label class="form-control"> <a href=localhost:8888\PhpProject4\Uploads\<?php echo$txt;?> ><?php echo $txt;?></a> </label> <br>
                                                 
                                                 
                                                        <?php if (isset($xx->text_desc))  {    ?>
                                             
                                                 <label  class="form-control" > <?php echo $text_desc[$key4];?></label>
                                                 
                                                  <?php }}} }?>
                                                 
                                                 
                                                 <?php
                                                  if(isset($xx->xls)&& count($xx->xls)>0){
                                                  $xls_array=$xx->xls;
                                                  foreach ($xls_array as $key5 => $xls){
                                              if($xls_array[$key5] != ""){
                                             ?>
                                                 
                                                  <label>xls file:</label> <br>
                                            
                                            <label class="form-control"> <a href=localhost:8888\PhpProject4\Uploads\<?php echo$xls;?> ><?php echo $xls;?></a> </label> <br>
                                                 
                                                 
                                                        <?php if (isset($xx->xls_desc))  {    ?>
                                             
                                                 <label  class="form-control" > <?php echo $xls_desc[$key5];?></label>
                                                 
                                                  <?php }}} }?>
                                                 
                                                 
                                                 
                                                 
                                             </div>
                                             <br> <br> <br>
                                                       
                                                    </div>
                                                <button class="status-Confirm" type="button" name="confirm" onclick="confirm(<?php echo $theid; ?>)" > Confirm</button>  <button name="reject" class="status-reject" type="button"  onClick="toggleFields()"  >Reject</button>  
                                                <br>
                                                    <div id="fields" style="display:none">
                                                        
                                                        <label >Write your feedback </label>
                                                        <textarea type="text" name="review" id="review" placeholder="Name" class="form-control"> </textarea>
                            
                                                        <br>
                                                        <button type="button" id="contact-btn" onclick="reject(<?php echo $theid; ?>)">Send your Feedback </button>
                                                        
                                                    </div>
                                                
                                        </div>
                                                
                                              
                                                   
                                                








                                            

    <?php
}
?> 
                             








                            </div></div></div></div>

        </section>










 


        <script>
function toggleFields(){
    $('#fields').toggle();
 }

            let sidebar = document.querySelector(".sidebar");
            let sidebarBtn = document.querySelector(".sidebarBtn");
            sidebarBtn.onclick = function () {
                sidebar.classList.toggle("active");
                if (sidebar.classList.contains("active")) {
                    sidebarBtn.classList.replace("bx-menu", "bx-menu-alt-right");
                } else
                    sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
            }</script>
        
        
         
         <script>
           
        function confirm(id) {


            $.ajax({

                url: "confirm.php",
                method: "POST",
                data: {id:id},
                dataType: 'text',

                success: function (e) {
                    console.log(e);
         
    }   });}
   
   function reject(id) {
 
           let review=$("#review").val();
          
            $.ajax({

                url: "reject.php",
                method: "POST",
                data: {id:id , review: review},
                dataType: 'text',

                success: function (e) {
                    console.log(e);
         
    }}   );}
   
   
   
   
   
   
   
       </script>


    </body>






</html>