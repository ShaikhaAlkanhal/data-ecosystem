<?php
 session_start();
 include 'connection.php';

       ?>


<!doctype html>
<html>
    <head>
        <title>Projects</title>
   <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="style.css">
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap.min.js"></script>		
<link rel="stylesheet" href="css/dataTables.bootstrap.min.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>


    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    


   
    
    <style>
        
    TableContainer {
  border-collapse: collapse;
  box-shadow: 0 5px 10px #e1e5ee;
  background-color: white;
  text-align: left;
  overflow: hidden;}

  thead {
    box-shadow: 0 5px 10px #e1e5ee;
  }

  th {
    padding: 1rem 2rem;
    text-transform: uppercase;
    letter-spacing: 0.1rem;
    font-size: 0.7rem;
    font-weight: 900;
  }

  td {
    padding: 1rem 2rem;
  }

  a {
    text-decoration: none;
    color: #2962ff;
  }

 
    
     .status-Confirm{
      background-color: #c8e6c9;
      color: #388e3c;
       padding: 0.1rem;
    text-align: center;
    border-radius: 0.2rem;
    }
   
    .status-pending{
        background-color: #fff0c2;
        color:  #a68b00;
         padding: 0.1rem;
    text-align: center;
    border-radius: 0.2rem;
    }
    .status-reject{
        background-color: #ffcdd2;
            color: #c62828;
        padding: 0.1rem;
    text-align: center;
    border-radius: 0.2rem;
    }

    </style>
        
    
    
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
   <div class="cont1">
  <?php
    if (isset($_GET['msg1']) == "insert") {
      echo "<div class='alert alert-success alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert'>&times;</button>
              Your Registration added successfully
            </div>";
      } 
    if (isset($_GET['msg2']) == "update") {
      echo "<div class='alert alert-success alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert'>&times;</button>
              Your Registration updated successfully
            </div>";
    }
    if (isset($_GET['msg3']) == "delete") {
      echo "<div class='alert alert-success alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert'>&times;</button>
              Record deleted successfully
            </div>";
    }
  ?> 
    
    
    
    
    
    
    
    
    
  <div class="sidebar">
    <div class="logo">

      <span class="logo_name">Admin Home Page</span>
    </div>
      <ul class="nav-links">
        <li>
            <a href="AdminHomePage.php" class="active">
            <i class='bx bx-grid-alt' ></i>
            <span class="links_name">Dashboard</span>
          </a>
        </li>

        <li>
            <a href="CreateTask.php">
            <i class='bx bx-box' ></i>
            <span class="links_name">Create Task</span>
          </a>
        </li>

 <li>
            <a href="projects.php">
            <i class='bx bx-message' ></i>
            <span class="links_name">Projects </span>
          </a>
        </li>
        
        
        
        <li>
            <a href="CreateUser.php">
            <i class='bx bx-user' ></i>
            <span class="links_name">Create User</span>
          </a>
        </li>
         <li>
            <a href="DeleteUser.php">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Delete User</span>
          </a>
        </li>
        <li>
            <a href="Download.php">
            <i class='bx bx-coin-stack' ></i>
            <span class="links_name">Downloads</span>
          </a>
        </li>
       

       
        <li class="log_out">
          <a href="#" onclick="window.location.href='index.php'">
            <i class='bx bx-log-out'></i>
            <span class="links_name">Log out</span>
          </a>
        </li>
      </ul>
  </div>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">Projects</span>
      </div>
      <div class="search-box">
        <input type="text" placeholder="Search...">
        <i class='bx bx-search' ></i>
      </div>
      <div class="profile-details">
        <!--<img src="images/profile.jpg" alt="">-->
        <span class="admin_name">Admin name</span>
        <i class='bx bx-chevron-down' ></i>
      </div>
    </nav>

 <br><br><br><br><br>
    <div class="home-content1">
      <div class="overview-boxes1">
        <div class="box1">
          <div class="right-side">
              
             <div class="card-body">
      
                
               <table id="table" class="TableContainer">
			<thead>
			<tr>
			<th>ID</th>
			<th>Project Name</th>					
			<th>User Name</th>	
                        <th> Status</th>
			
			</tr>
			</thead>
			<tbody>
	<?php
									
	$payroll=$conn->query("SELECT id , task_name , status , user_id FROM forminfo2 WHERE admin_id = '".$_SESSION['id']."'") ;

	while($row=$payroll->fetch_array()){
             $id1 = $row ['id'];
             $userID = $row['user_id'];
         $res = $conn ->query("SELECT * FROM user_responses WHERE form_id ='$id1'");
         $row2 = $res -> fetch_array();
                 $res2 = $conn ->query("SELECT username FROM user WHERE id ='$userID'");
         $row7 = $res2 -> fetch_array();
	?>
	<tr>
            
	<td><?php echo $row['id']?></td>
         <?php echo "<td><a href='reviewforms.php?id={$id1}'>{$row['task_name']}</a></td>";?>
        <td> <?php echo $row7['username']?></td>
        
       
        <?php
       
        if($row['status']==0){
        ?>
        
        <td>
          <p class="status-pending">Pending</p>
        </td>
          
	
            <?php
            }
            elseif ($row['status']==2){
                
                
                
            ?>
        <td>
          <p class="status-reject">Rejected</p>
        </td>   
        
           
              <?php
              
            }
            else{
                
                ?>
        
         <td>
          <p class="status-Confirm">Confirmed</p>
        </td>   
        <?php
            }
             
                    
            ?>
            
	
	</tr>
	<?php
	}
	?>
	</tbody>
	</table>
                 
        
           
	</div>
 
          
          </div></div></div></div>
       
    </section>
       
    
    	
	<script type="text/javascript">
		$(document).ready(function(){
			$('#table').DataTable();
		});
	</script>
	

    <script>

   let sidebar = document.querySelector(".sidebar");
let sidebarBtn = document.querySelector(".sidebarBtn");
sidebarBtn.onclick = function() {
  sidebar.classList.toggle("active");
  if(sidebar.classList.contains("active")){
  sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right"); }else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu"); }  </script>

</body>

    
    
    
    
    
</html>
