<?php
 session_start();
// Create database connection
include 'connection.php';

?>


<!DOCTYPE html>
<html>
    <head>
        <title>Create Task</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="stylesheet" href="style.css">

        <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script src="//geodata.solutions/includes/countrystatecity.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
              crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

        <style type="text/css">


            form div {
                margin-top: 5px;
            }

            #img_div {
                width: 80%;
                padding: 5px;
                margin: 15px auto;
                border: 1px solid #cbcbcb;
            }

            #img_div:after {
                content: "";
                display: block;
                clear: both;
            }

            img {
                float: left;
                margin: 5px;
                width: 300px;
                height: 140px;
            }
        </style>





    </head>
    <body>
        <div id="content">
            

            <div class="sidebar">
                <div class="logo">

                    <span class="logo_name">Admin Home Page</span>
                </div>
                <ul class="nav-links">
                    <li>
                        <a href="AdminHomePage.php" class="active">
                            <i class='bx bx-grid-alt'></i>
                            <span class="links_name">Dashboard</span>
                        </a>
                    </li>

                    <li>
                        <a href="CreateTask.php">
                            <i class='bx bx-box'></i>
                            <span class="links_name">Create Task</span>
                        </a>
                    </li>
 <li>
            <a href="projects.php">
            <i class='bx bx-message' ></i>
            <span class="links_name">Projects </span>
          </a>
        </li>


                    <li>
                        <a href="CreateUser.php">
                            <i class='bx bx-user'></i>
                            <span class="links_name">Create User</span>
                        </a>
                    </li>
                    
                     <li>
            <a href="DeleteUser.php">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name">Delete User</span>
          </a>
        </li>
                    <li>
                        <a href="Download.php">
                            <i class='bx bx-coin-stack'></i>
                            <span class="links_name">Downloads</span>
                        </a>
                    </li>
                    
                    <li class="log_out">
                        <a href="logOut.php" onclick="window.location.href = 'index.php'">
                            <i class='bx bx-log-out'></i>
                            <span class="links_name">Log out</span>
                        </a>
                    </li>
                </ul>
            </div>


            <section class="home-section">

                <nav>
                    <div class="sidebar-button">
                        <i class='bx bx-menu sidebarBtn'></i>
                        <span class="dashboard">Create Task</span>
                    </div>
                    <div class="search-box">
                        <input type="text" placeholder="Search...">
                        <i class='bx bx-search'></i>
                    </div>
                    <div class="profile-details">
                        <!--<img src="images/profile.jpg" alt="">-->
                        <span class="admin_name">Admin name</span>
                        <i class='bx bx-chevron-down'></i>
                    </div>
                </nav>

                <br><br><br><br>
                <div class="home-content1">
                    <div class="overview-boxes1">
                        <div class="box1">
                            <div class="right-side">

                                <div class="mt-5 alert alert-danger alert-dismissible fade error_display">
                                    <a href="#" class="close" aria-label="close">&times;</a>

                                </div>
                                <div class="container" style="width:600px;">


                                    <form id="main_form" method="POST" action="">
                                        <input type="hidden" name="size" value="1000000">
                                        <div class="form-group">
                                            <br><br>
                                            <!-- <label>Enter Your Name:</label>
                                           <input type="text" name="name" id="name" class="form-control"/> -->
                                            <label>Enter the Task Name:</label>
                                            <input type="text" name="task_name" id="name" class="form-control"/>
                                            <br>
                                            <label>Upload guidelines:</label>

                                            <div class="form-row" >
                                                <div class="col">

                                                    <input type="file" class="form-control" name="guide_lines" id="guide_lines">
                                                    <input type="hidden" id="admin_id" value="<?Php echo $_SESSION['id']?>">
                                                    <input type="hidden" id="form_id" >
                                                    <br>

                                                    <label>Deadline:</label><input type="date" name="deadline"  class="form-control" /><br>
                                                    <label>Number of samples:</label><input type="number" min="0" id="samples" name="samples"  class="form-control" />


                                                    <br>
                                                    <label>Users:</label>
                                                    <select  class="form-control" name="user" >
                                                        <option disabled selected>-- Select User --</option>
                                                        <?php
                                                        $users = mysqli_query($conn, "SELECT id , username From user ");

                                                        while ($data = mysqli_fetch_array($users)) {
                                                            echo "<option value='" . $data['id'] . "'>" . $data['username'] . "</option>";
                                                        }
                                                        ?>  
                                                    </select>
                                                </div></div>
                                            <br>
                                            <label> Media type:  </label>

                                            <div id="dynamic_field">
                                                <div class="form-row" >
                                                    <div class="col">
                                                        <select  class="form-control" name="media[]" id="media" >
                                                            <option disabled selected>-- Select media type --</option>
                                                            <option value="video">Video</option>
                                                            <option value="image">Image</option>
                                                            <option value="audio">Audio</option>
                                                            <option value="text">Text</option>
                                                            <option value="xls">xls</option>

                                                        </select>
                                                        <br>
                                                        <select name="media_required[]" class="form-control">
                                                            <option value='' disabled selected >Is media required?</option>
                                                            <option value="1">Yes</option>
                                                            <option value="0">No</option>
                                                        </select>
                                                        <br>
                                                        <select name="media_description_req[]" class="form-control">
                                                            <option value='' disabled selected >Is media description required?</option>
                                                            <option value="1">Yes</option>
                                                            <option value="0">No</option>
                                                        </select>
      
                                                        
                                                        
                                                        
                                                        

                                                        <br>

                                                    </div>

                                                    <div class="col">
                                                        <td><button type="button" name="add" id="add" class="btn btn-success"><i class="fa fa-plus"></i></button></td>
                                                    </div>
                                                    
                                                </div></div>  

                                                    



                                            


                                            <div class="form-group">

                                                <br>
                                                <button type="button" name="submit" class="btn btn-info" value="Save"
                                                        onclick="submit_form()"> Save
                                                </button>
                                            </div> </div>
                                    </form>
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    <script src="https://code.jquery.com/jquery-3.6.0.min.js" crossorigin="anonymous"></script>



                                    <script src="https://code.jquery.com/jquery-3.6.0.min.js" crossorigin="anonymous"></script>
                                    <script>
                                                            $(document).ready(function () {
                                                                var i = 1;
                                                                $('#add').click(function () {
                                                                    i++;
                                                                    $('#dynamic_field').append('<div class="form-row" id="row' + i + '"> <div class="col">  <select  class="form-control" name="media[]" > <option disabled selected>-- Select media type --</option> <option value="video">Video</option>  <option value="image">Image</option> <option value="audio">Audio</option> <option value="text">Text</option><option value="xls">xls</option> </select><br><select  class="form-control" name="media_required[]" > <option disabled selected> Is media required? </option> <option value="1">Yes</option>  <option value="0">No</option> </select> <br><select  class="form-control" name="media_description_req[]" > <option disabled selected> Is media description required? </option> <option value="1">Yes</option>  <option value="0">No</option> </select> </div>  <div class="col"> <td><button type="button" name="add" class="btn btn-danger btn_remove" id="' + i + '"><i class="fa fa fa-trash"></i></button></td> </div> </div>');
                                                                });
                                                                $(document).on('click', '.btn_remove', function () {
                                                                    var button_id = $(this).attr("id");

                                                                    $('#row' + button_id + '').remove();
                                                                });


                                                                


                                                            });
                                    </script>


                                </div>


                            </div>
                        </div>
                    </div>
                </div>
            </section>


            <script>
                let sidebar = document.querySelector(".sidebar");
                let sidebarBtn = document.querySelector(".sidebarBtn");
                sidebarBtn.onclick = function () {
                    sidebar.classList.toggle("active");
                    if (sidebar.classList.contains("active")) {
                        sidebarBtn.classList.replace("bx-menu", "bx-menu-alt-right");
                    } else
                        sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
                }</script>


    </body>


    <script>
        function submit_form() {

            let datastring = $("#main_form").serialize();



            let admin_id=$("#admin_id").val();


            $.ajax({

                url: "insert.php",
                method: "POST",
                data: datastring+"& id="+admin_id,
                dataType: 'json',

                success: function (e) {
                    console.log(e);
                    if(e.error ==0){

                     //   $("#form_id").val(e.form_id);
                        window.form_id=e.form_id;
                        /*if (e.error == 1) {
                            $(".error_display").removeClass("fade");
                            $(".error_display").html(e.message);
                        } else {
                            window.location.href = "projects.php";
                        }*/
                        /*************/
                        var file_data = $('#guide_lines').prop('files')[0];
                        var form_data = new FormData();
                        form_data.append('file', file_data);
                        form_data.append('id',   window.form_id);
                        form_data.append('samples',   $("#samples").val());
                        //   form_data.append('id',  $("#form_id").val());
                        $.ajax({
 
                            url: "insert_files.php",
                            method: "POST",
                            data: form_data,
                            dataType: 'text',
                            cache: false,
                            contentType: false,
                            processData: false,

                            success: function (e) {
                                console.log(e);
                                /*if (e.error == 1) {
                                    $(".error_display").removeClass("fade");
                                    $(".error_display").html(e.message);
                                } else {
                                    window.location.href = "projects.php";
                                }*/

                            }
                        });
                    }

                }
            });
        }

    </script>


    <!--
    <script>
   
    var app = angular.module('dynamicApp', []);
   
    app.controller('dynamicController', function($scope, $http){
   
     $scope.success = false;
     $scope.error = false;
   
     $scope.fetchData = function(){
      $http.get('fetch_data.php').success(function(data){
       $scope.namesData = data;
      });
     };
   
     $scope.rows = [{name: 'programming_languages[]', name: 'remove'}];
   
     $scope.addRow = function(){
      var id = $scope.rows.length + 1;
      $scope.rows.push({'id':'dynamic'+id});
     };
   
     $scope.removeRow = function(row){
      var index = $scope.rows.indexOf(row);
      $scope.rows.splice(index, 1);
     };
   
     $scope.formData = {};
   
     $scope.submitForm = function(){
      $http({
       method:"POST",
       url:"insert.php",
       data:$scope.formData
      }).success(function(data){
       if(data.error != '')
       {
        $scope.success = false;
        $scope.error = true;
        $scope.errorMessage = data.error;
       }
       else
       {
        $scope.success = true;
        $scope.error = false;
        $scope.successMessage = data.message;
        $scope.formData = {};
        $scope.rows = [{name: 'programming_languages[]', name: 'remove'}];
        $scope.fetchData();
       }
      });
     };
   
    });
   
    </script> -->
</html>
