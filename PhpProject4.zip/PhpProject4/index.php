
<?php
session_start();
?>
<!doctype html>
<html>
    <head>
    <meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1.0">
       <title>Home Page</title>
        <link rel="stylesheet" href="newcss.css">
    </head>  
    
    
    <body>
       <main>
           <div class="cont">
               <div class="cont2">
                   <br><br> <br><br> <br><br> <br><br> <br><br> <br><br>
                   <button onclick="window.location.href='AdminSignUp.php';" class="button-one"> Admin </button>
                   <br><br>
                   <button onclick="window.location.href='UserSignUp.php';" class="button-one"> User  </button>
                   
                   
                   
               </div>
              
           </div>    
            
            
          
        </main>
        
        
        
        
    </body>
    
    
    
</html>
