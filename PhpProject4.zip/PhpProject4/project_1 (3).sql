-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Aug 11, 2021 at 08:14 PM
-- Server version: 5.7.24
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project 1`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(42) NOT NULL,
  `email` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `email`) VALUES
(99, 'aaaazzz', '5db60c3a767a3b5d19ce22f51c0c374a', 'zzzss@gmail.com'),
(100, 's', 'b59c67bf196a4758191e42f76670ceba', 's@gmail.com'),
(101, 'a', 'b59c67bf196a4758191e42f76670ceba', 'a@gmail.com'),
(102, 'z', 'ad57484016654da87125db86f4227ea3', 'z@gmail.com'),
(103, 'd', 'b59c67bf196a4758191e42f76670ceba', 'd@gmail.com'),
(104, 'y', '3691308f2a4c2f6983f2880d32e29c84', 'y@gmail.com'),
(105, 'dana', 'b59c67bf196a4758191e42f76670ceba', 'dana@gmail.com'),
(106, 'j', '6512bd43d9caa6e02c990b0a82652dca', 'j@gmail.com'),
(107, 'c', '698d51a19d8a121ce581499d7b701668', 'c@gmail.com'),
(108, 'sara', '698d51a19d8a121ce581499d7b701668', 'sara@gmail.com'),
(109, 'lulu', 'b0baee9d279d34fa1dfd71aadb908c3f', 'lulu@gmail.com'),
(110, 'shaikha1', '202cb962ac59075b964b07152d234b70', 'shaikha1@gmail.com'),
(111, 'lulu11', '202cb962ac59075b964b07152d234b70', 'lulu11@gmail.com'),
(112, 'deema', '202cb962ac59075b964b07152d234b70', 'deema@gmail.com'),
(113, 'yess', '6512bd43d9caa6e02c990b0a82652dca', 'yess@gmail.com'),
(114, 'xx', '202cb962ac59075b964b07152d234b70', 'e@gmail.com'),
(115, 'wind', '202cb962ac59075b964b07152d234b70', 'wind@gmail.com'),
(116, 'windows', '202cb962ac59075b964b07152d234b70', 'windows@gmail.com'),
(117, 'test2', '202cb962ac59075b964b07152d234b70', 'test2@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `forminfo`
--

CREATE TABLE `forminfo` (
  `id` int(10) NOT NULL,
  `country` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `image` varchar(255) NOT NULL,
  `audio` varchar(255) NOT NULL,
  `video` varchar(255) NOT NULL,
  `xls` varchar(255) NOT NULL,
  `review` varchar(40) NOT NULL,
  `name` varchar(30) NOT NULL,
  `projectName` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `forminfo2`
--

CREATE TABLE `forminfo2` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `task_name` varchar(100) NOT NULL,
  `guide_lines` varchar(255) DEFAULT NULL,
  `review` text,
  `status` int(11) DEFAULT NULL COMMENT '0:created,1:accepted,2:rejected',
  `deadline` date NOT NULL,
  `create_on` date NOT NULL,
  `country` varchar(30) DEFAULT NULL,
  `state` varchar(30) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `forminfo2`
--

INSERT INTO `forminfo2` (`id`, `admin_id`, `user_id`, `task_name`, `guide_lines`, `review`, `status`, `deadline`, `create_on`, `country`, `state`, `city`) VALUES
(19, 114, 1, 'testwind', 'شعار-هدف.jpg', NULL, NULL, '2021-09-16', '2021-08-01', '', '', ''),
(32, 117, 1, 'saraTask', '', ' test the feeback', 2, '2021-09-23', '2021-08-01', '', '', ''),
(33, 117, 2, 'user1Task', '', NULL, 1, '2021-09-23', '2021-08-01', '', '', ''),
(35, 117, 2, 'googletask2', 'google2.jpeg', '', 2, '2021-09-30', '2021-08-02', '', '', ''),
(36, 117, 1, 'wordtask', 'محضر الاجتماع.docx', ' test reject', 2, '2021-10-07', '2021-08-02', '', '', ''),
(37, 117, 1, 'wordtask2', 'MOM_SMEA_21-06-2021.docx', '', 2, '2021-10-06', '2021-08-02', '', '', ''),
(38, 117, 1, 'saraedia', NULL, NULL, 1, '2021-09-15', '2021-08-02', NULL, NULL, NULL),
(39, 117, 1, 'testmedia', NULL, NULL, 0, '2021-09-29', '2021-08-02', 'Greece', 'Mount Athos', 'Karyes'),
(40, 117, 1, 'task3', 'MOM_SMEA_21-06-2021.docx', '', 2, '2021-09-15', '2021-08-03', 'Germany', 'Berlin', 'Berlin'),
(42, 117, 1, 'project1', 'MOM_SMEA_21-06-2021.docx', NULL, 0, '2021-09-24', '2021-08-04', 'Saudi Arabia', 'Ar Riyad', 'Riyadh'),
(88, 117, 2, 'testsamples', 'MOM_SMEA_21-06-2021.docx', NULL, NULL, '2021-10-12', '2021-08-05', NULL, NULL, NULL),
(89, 117, 2, 'testsamples', 'MOM_SMEA_21-06-2021.docx', NULL, NULL, '2021-10-12', '2021-08-05', NULL, NULL, NULL),
(90, 117, 2, 'testsamples', 'MOM_SMEA_21-06-2021.docx', NULL, NULL, '2021-10-12', '2021-08-05', NULL, NULL, NULL),
(91, 117, 2, 'testsamples', 'MOM_SMEA_21-06-2021.docx', NULL, NULL, '2021-10-12', '2021-08-05', NULL, NULL, NULL),
(92, 117, 2, 'testafter', 'محضر الاجتماع.docx', NULL, NULL, '2021-10-12', '2021-08-05', NULL, NULL, NULL),
(93, 117, 2, 'testmedia', 'التسهيلات المقدمة لذوي الاحتياجات الخاصة.docx', NULL, NULL, '2021-09-22', '2021-08-07', NULL, NULL, NULL),
(94, 117, 2, 'testmedia', 'التسهيلات المقدمة لذوي الاحتياجات الخاصة.docx', NULL, NULL, '2021-09-22', '2021-08-07', NULL, NULL, NULL),
(95, 117, 1, 'samples0', 'MOM_SMEA_21-06-2021.docx', NULL, NULL, '2021-09-15', '2021-08-11', NULL, NULL, NULL),
(96, 117, 1, 'samples0', 'MOM_SMEA_21-06-2021.docx', NULL, NULL, '2021-09-15', '2021-08-11', NULL, NULL, NULL),
(97, 117, 1, 'samples0', 'MOM_SMEA_21-06-2021.docx', NULL, NULL, '2021-09-15', '2021-08-11', NULL, NULL, NULL),
(98, 117, 1, 'samples0', 'MOM_SMEA_21-06-2021.docx', NULL, NULL, '2021-09-15', '2021-08-11', NULL, NULL, NULL),
(99, 117, 1, 'samples0', 'MOM_SMEA_21-06-2021.docx', NULL, NULL, '2021-09-15', '2021-08-11', NULL, NULL, NULL),
(100, 117, 10, 'usser2', '', NULL, NULL, '2021-09-23', '2021-08-11', 'Qatar', 'Baladiyat ad Dawhah', 'Doha');

-- --------------------------------------------------------

--
-- Table structure for table `form_media`
--

CREATE TABLE `form_media` (
  `id` int(11) NOT NULL,
  `form_id` int(11) NOT NULL,
  `media_name` varchar(255) NOT NULL,
  `media_description_req` int(2) NOT NULL,
  `media_required` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `form_media`
--

INSERT INTO `form_media` (`id`, `form_id`, `media_name`, `media_description_req`, `media_required`) VALUES
(1, 39, 'image', 1, 1),
(2, 39, 'video', 0, 0),
(5, 42, 'image', 1, 1),
(6, 42, 'image', 0, 1),
(9, 93, 'image', 0, 1),
(10, 93, 'image', 0, 0),
(11, 94, 'image', 0, 1),
(12, 94, 'image', 0, 0),
(13, 95, 'image', 1, 1),
(14, 96, 'image', 1, 1),
(15, 97, 'image', 1, 1),
(16, 98, 'image', 1, 1),
(17, 99, 'image', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(42) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `password`) VALUES
(1, 'sara', 'sara@gmail.com', '202cb962ac59075b964b07152d234b70'),
(5, 'reem', 'reem@gmail.com', '202cb962ac59075b964b07152d234b70'),
(6, 'leen', 'leen@gmail.com', '202cb962ac59075b964b07152d234b70'),
(7, 'deem', 'deem@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055'),
(8, 'testcreate', 'testcreate@gmail.com', 'b0baee9d279d34fa1dfd71aadb908c3f');

-- --------------------------------------------------------

--
-- Table structure for table `user_responses`
--

CREATE TABLE `user_responses` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `form_id` int(11) NOT NULL,
  `response` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `created_on` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_responses`
--

INSERT INTO `user_responses` (`id`, `user_id`, `form_id`, `response`, `created_on`) VALUES
(8, 1, 42, '{\"image\":[\"google2.jpeg\",\"cl11.png\"],\"image_desc\":[\"number1\",\"number2\"]}', '2021-08-04'),
(10, 10, 100, '[]', '2021-08-11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `forminfo`
--
ALTER TABLE `forminfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `forminfo2`
--
ALTER TABLE `forminfo2`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `form_media`
--
ALTER TABLE `form_media`
  ADD PRIMARY KEY (`id`),
  ADD KEY `form_id` (`form_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_responses`
--
ALTER TABLE `user_responses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `form_id` (`form_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=118;

--
-- AUTO_INCREMENT for table `forminfo`
--
ALTER TABLE `forminfo`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `forminfo2`
--
ALTER TABLE `forminfo2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `form_media`
--
ALTER TABLE `form_media`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user_responses`
--
ALTER TABLE `user_responses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
