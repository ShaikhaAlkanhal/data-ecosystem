

<?php
session_start();
?>

<!doctype html>
<html>
    <head>
   <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="style.css">

    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <script src="javaScript.js"></script>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="sidebar">
    <div class="logo">

      <span class="logo_name">User Home Page</span>
    </div>
      <ul class="nav-links">
        <li>
          <a href="#" class="active">
            <i class='bx bx-grid-alt' ></i>
            <span class="links_name">Dashboard</span>
          </a>
        </li>
        <li>
            <a href="userProjects.php">
            <i class='bx bx-message' ></i>
            <span class="links_name">Projects </span>
          </a>
        </li>

        <li>
            <a href="#">
            <i class='bx bx-box' ></i>
            <span class="links_name">Feedback</span>
          </a>
        </li>



        <li>
          <a href="#">
            <i class='bx bx-cog' ></i>
            <span class="links_name">Settings</span>
          </a>
        </li>
        <li class="log_out">
          <a href="#" onclick="window.location.href='index.php'">
            <i class='bx bx-log-out'></i>
            <span class="links_name">Log out</span>
          </a>
        </li>
      </ul>
  </div>
  <section class="home-section">
    <nav>
     <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">Projects</span>
      </div>
      <div class="search-box">
        <input type="text" placeholder="Search...">
        <i class='bx bx-search' ></i>
      </div>
      <div class="profile-details">
        <!--<img src="images/profile.jpg" alt="">-->
        <span class="admin_name">User name</span>
        <i class='bx bx-chevron-down' ></i>
      </div>
    </nav>

    <div class="home-content">
      <div class="overview-boxes">
        <div class="box">
          <div class="right-side">
            <div class="box-topic"> Summary </div>
            <div class="number"> </div>
            <div class="indicator">

              <span class="text"> </span>
            </div>
          </div>

        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic"> Data</div>
            <div class="number"></div>
            <div class="indicator">

              <span class="text"></span>
            </div>
          </div>

        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic"></div>
            <div class="number"></div>
            <div class="indicator">

              <span class="text"></span>
            </div>
          </div>

        </div>
        <div class="box">
          <div class="right-side">
            <div class="box-topic"></div>
            <div class="number"></div>
            <div class="indicator">

              <span class="text"></span>
            </div>
          </div>

        </div>
      </div>

      <div class="sales-boxes">
        <div class="recent-sales box">
          <div class="title">Gallery</div>
          <!-- Container for the image gallery -->
<div class="container">

  <!-- Full-width images with number text -->
  <div class="mySlides">
    <div class="numbertext">1 / 6</div>
      <img src="" >
  </div>

  <div class="mySlides">
    <div class="numbertext">2 / 6</div>
      <img src="" >
  </div>

  <div class="mySlides">
    <div class="numbertext">3 / 6</div>
      <img src="" >
  </div>

  <div class="mySlides">
    <div class="numbertext">4 / 6</div>
      <img src="" >
  </div>

  <div class="mySlides">
    <div class="numbertext">5 / 6</div>
      <img src="" >
  </div>

  <div class="mySlides">
    <div class="numbertext">6 / 6</div>
      <img src="" >
  </div>

  <!-- Next and previous buttons -->
  <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
  <a class="next" onclick="plusSlides(1)">&#10095;</a>

  <!-- Image text -->
  <div class="caption-container">
    <p id="caption"></p>
  </div>

  <!-- Thumbnail images -->
  <div class="row">
    <div class="column">
      <img class="demo cursor" src="" width="300" height="300" onclick="currentSlide(1)" >
    </div>
    <div class="column">
      <img class="demo cursor" src=""width="300" height="300"  onclick="currentSlide(2)" >
    </div>
    <div class="column">
      <img class="demo cursor" src=""width="300" height="300" onclick="currentSlide(3)" >
    </div>
    <div class="column">
      <img class="demo cursor" src="" width="300" height="300"  onclick="currentSlide(4)" >
    </div>
    <div class="column">
      <img class="demo cursor" src="" width="300" height="300" onclick="currentSlide(5)" >
    </div>
    <div class="column">
      <img class="demo cursor" src="" width="300" height="300"  onclick="currentSlide(6)" >
    </div>
  </div>
</div>
          
          <div class="sales-details">
            <ul class="details">
              <li class="topic"></li>

            </ul>
            <ul class="details">
            <li class="topic"></li>

          </ul>
          <ul class="details">
            <li class="topic"></li>

          </ul>
          <ul class="details">
            <li class="topic"></li>

          </ul>
          </div>

        </div>
        <div class="top-sales box">
          <div class="title">Map</div>
          
          
          
          <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d15300.941147813362!2d46.64279029491766!3d24.740628064454377!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sar!2ssa!4v1625998782272!5m2!1sar!2ssa" width="300" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
          <ul class="top-sales-details">


          <li>
            <a href="#">

              <span class="product"></span>
            </a>
            <span class="price"></span>
          </li>

          </ul>
        </div>
      </div>
    </div>
  </section>

  <script>
   let sidebar = document.querySelector(".sidebar");
let sidebarBtn = document.querySelector(".sidebarBtn");
sidebarBtn.onclick = function() {
  sidebar.classList.toggle("active");
  if(sidebar.classList.contains("active")){
  sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right"); }else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu"); }  </script>

</body>

    
    
    
    
    
</html>